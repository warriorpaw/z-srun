
// ras_acsiiDlg.h : header file
//

#pragma once


// Cras_acsiiDlg dialog
class Cras_acsiiDlg : public CDialogEx
{
// Construction
public:
	Cras_acsiiDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	enum { IDD = IDD_RAS_ACSII_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	CEdit m_Name;
	CEdit m_Pass;
	CEdit m_Ver;
	char name[100];
	char pass[100];
	int ver;
	afx_msg void OnBnClickedOk();
	RASDIALPARAMS RasDialParams;
	RASCONNSTATUS RasConnStatus;
	HRASCONN m_hRasConn;
	bool Dail(void);
	//static void  RasDialFunc(HRASCONN hrasconn, UINT unMsg, RASCONNSTATE rascs, DWORD dwError, DWORD dwExtendedError);
	afx_msg void OnBnClickedCancel();
//	RASENTRY r_entry;
	CEdit m_Log;
	afx_msg void OnBnClickedButton1();
	CEdit m_Rascon;
	CEdit m_Udpcon;
	CButton m_ck;
};
