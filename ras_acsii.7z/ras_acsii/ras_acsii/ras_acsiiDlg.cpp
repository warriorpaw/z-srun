
// ras_acsiiDlg.cpp : implementation file
//

#include "stdafx.h"
#include "ras_acsii.h"
#include "ras_acsiiDlg.h"
#include "afxdialogex.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// Cras_acsiiDlg dialog

void __stdcall RasDialFunc(UINT unMsg, RASCONNSTATE rascs, DWORD dwError);

HRASCONN hRasConn;
char mac[50];
char IP_[50];
CEdit *Log = 0;
CEdit *rascon = 0;
CEdit *udpcon = 0;
SOCKET _udp = 0;
int runing = 0;
int UDPflag = 0;
char _name[50];
int _ver;
CWinThread *_sendudp;
int udp_con[2] = {0};
int ras_con[2] = {0};
HWND hWnd;
void updatelog(char *buf)
{
	CString tmp;
	if (Log)
	{
		Log->GetWindowTextA(tmp);
		tmp.Append(buf);
		tmp.Append("\r\n");
		Log->SetWindowTextA((LPCTSTR)tmp);
		Log->LineScroll(Log->GetLineCount());
	}
}

void kill_()
{
	if(hRasConn)
	{
		RasHangUp(hRasConn);
		updatelog("kill _ RasHangUp!");
		hRasConn = 0;
		runing = 0;
		mac[0] = 0;
		closesocket(_udp);
	}
}

void showIPs()
{
	mac[0] = 0;
	memset(IP_,0,50);
	char tmp[100];
	PIP_ADAPTER_INFO pAdapterInfo;
	PIP_ADAPTER_INFO pAdapter = NULL;
	ULONG ulOutBufLen = sizeof(IP_ADAPTER_INFO);
	pAdapterInfo = (PIP_ADAPTER_INFO)malloc(ulOutBufLen);
	DWORD dwRetVal = GetAdaptersInfo( pAdapterInfo, &ulOutBufLen);
	// ��һ�ε���GetAdapterInfo��ȡulOutBufLen��С
	if (dwRetVal == ERROR_BUFFER_OVERFLOW)
	{
		free(pAdapterInfo);
		pAdapterInfo = (IP_ADAPTER_INFO *) malloc (ulOutBufLen);
		dwRetVal = GetAdaptersInfo( pAdapterInfo, &ulOutBufLen);
	}
	if (dwRetVal == NO_ERROR)
	{
		pAdapter = pAdapterInfo;
		while (pAdapter)
		{
			sprintf(tmp,"Adapter Name: \t%s\n", pAdapter->AdapterName);
			updatelog(tmp);
			sprintf(tmp,"Adapter Desc: \t%s\n", pAdapter->Description);
			updatelog(tmp);
			sprintf(tmp,"MAC Addr: \t%02x:%02x:%02x:%02x:%02x:%02x\n",
				pAdapter->Address[0],
				pAdapter->Address[1],
				pAdapter->Address[2],
				pAdapter->Address[3],
				pAdapter->Address[4],
				pAdapter->Address[5]);
			updatelog(tmp);
			if (!strcmp(pAdapter->Description,"test") || strstr(pAdapter->Description,"PPP"))
			{
				sprintf(tmp,"%02x:%02x:%02x:%02x:%02x:%02x",
					pAdapter->Address[0],
					pAdapter->Address[1],
					pAdapter->Address[2],
					pAdapter->Address[3],
					pAdapter->Address[4],
					pAdapter->Address[5]);
				strcpy(mac,tmp);
				strcpy(IP_,pAdapter->IpAddressList.IpAddress.String);
			}
			sprintf(tmp,"IP Address: \t%s\n", pAdapter->IpAddressList.IpAddress.String);
			updatelog(tmp);
			sprintf(tmp,"IP Mask: \t%s\n", pAdapter->IpAddressList.IpMask.String);
			updatelog(tmp);
			sprintf(tmp,"Gateway: \t%s\n", pAdapter->GatewayList.IpAddress.String);
			updatelog(tmp);
			updatelog("--------------------------");
			pAdapter = pAdapter->Next;
		}// end while
	}
	else
	{
		updatelog("Call to GetAdaptersInfo failed.\n");
	}
}

UINT SendUDP(LPVOID pParam)
{
	unsigned long ul = 1; 
	int timeout = 50000;
	int ret;
	char buf[200];
	char buf2[25];
	struct sockaddr_in bing_add;
	struct sockaddr_in recv_add;
	int add_len = sizeof(struct sockaddr_in);
	memset(&bing_add,0,sizeof(struct sockaddr_in));
	bing_add.sin_family= 2;
	bing_add.sin_port = ntohs(0x3417u);
	_udp = socket(2, 2, 0);
	ret = bind(_udp,(sockaddr *)&bing_add,sizeof(struct sockaddr_in));
	if (ret == SOCKET_ERROR)
	{
		kill_();
		updatelog("bind error !!@");
		return 0;
	}
	if (setsockopt(_udp,SOL_SOCKET,SO_RCVTIMEO,(char *)&timeout,sizeof(timeout))==SOCKET_ERROR)
	{
		kill_();
		updatelog("setsockopt error !!@");
		return 0;
	}
	UDPflag = 0;
	bing_add.sin_family = AF_INET;
	bing_add.sin_addr.s_addr = inet_addr("172.16.108.13");
	bing_add.sin_port = htons(3338);
	Sleep(10000);
	while (runing)
	{
		memset(buf,0,200);
		if (UDPflag)
		{
			strcpy(buf, _name);
		} 
		else
		{
			strcpy(buf, "CHECK_VERSION");
			*(int *)(buf+52) = _ver;
		}
		if (mac[0])
		{
			strcpy(buf + 32, mac);
		}
		sendto(_udp, buf, 56, 0,(sockaddr *) &bing_add, sizeof(struct sockaddr_in));
		udp_con[1]++;
		sprintf(buf2,"%d / %d",udp_con[1],udp_con[0]);
		udpcon->SetWindowTextA(buf2);
		ret = recvfrom(_udp, buf, 200, 0, (sockaddr *)&recv_add, &add_len);
		UDPflag = 1;
		if (ret == -1)
		{
			updatelog("recvfrom time out !!@");
		} 
		else
		{
			udp_con[0]++;
			//updatelog("recvfrom OK @");
			Sleep(timeout);
		}
		sprintf(buf2,"%d / %d",udp_con[1],udp_con[0]);
		udpcon->SetWindowTextA(buf2);
	}
	return 0;
}

UINT checkras(LPVOID pParam)
{
	char buf[25];
	RASCONNSTATUS lprasconnstatus;
	while (runing)
	{
		memset(&lprasconnstatus,0,sizeof(lprasconnstatus));
		lprasconnstatus.dwSize = sizeof(lprasconnstatus);
		lprasconnstatus.dwSize = 288;
		ras_con[1]++;
		if(RasGetConnectStatus(hRasConn,&lprasconnstatus) == ERROR_SUCCESS)
		{
			if (lprasconnstatus.rasconnstate != RASCS_Connected)
			{
				updatelog("hRasConn state error!!");
				break;
			}
			else
				ras_con[0]++;
		}
		else
		{
			updatelog("RasGetConnectStatus error");
			break;
		}
		sprintf(buf,"%d / %d",ras_con[1],ras_con[0]);
		rascon->SetWindowTextA(buf);
		Sleep(3000);
	}
	updatelog("Maybe lost connection ! PLS retry!!");
	kill_();
	SetForegroundWindow(hWnd);
	return  0;
}

Cras_acsiiDlg::Cras_acsiiDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(Cras_acsiiDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	hRasConn = 0;
	ver = 0;
	Log = &m_Log;
	rascon = &m_Rascon;
	udpcon = &m_Udpcon;
}

void Cras_acsiiDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDIT1, m_Name);
	DDX_Control(pDX, IDC_EDIT2, m_Pass);
	DDX_Control(pDX, IDC_EDIT3, m_Ver);
	DDX_Control(pDX, IDC_EDIT6, m_Log);
	DDX_Control(pDX, IDC_EDIT5, m_Rascon);
	DDX_Control(pDX, IDC_EDIT7, m_Udpcon);
	DDX_Control(pDX, IDC_CHECK1, m_ck);
}

BEGIN_MESSAGE_MAP(Cras_acsiiDlg, CDialogEx)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDOK, &Cras_acsiiDlg::OnBnClickedOk)
	ON_BN_CLICKED(IDCANCEL, &Cras_acsiiDlg::OnBnClickedCancel)
	ON_BN_CLICKED(IDC_BUTTON1, &Cras_acsiiDlg::OnBnClickedButton1)
END_MESSAGE_MAP()


// Cras_acsiiDlg message handlers

BOOL Cras_acsiiDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// TODO: Add extra initialization here
	m_Ver.SetWindowTextA("117");
	hWnd = AfxGetMainWnd()->m_hWnd;
	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void Cras_acsiiDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR Cras_acsiiDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}



void Cras_acsiiDlg::OnBnClickedOk()
{
	char tmp[100];
	int i;
	m_Name.GetWindowTextA(tmp,100);
	strcpy(_name,tmp);
	strcpy(name,"{SRUN3}\r\n");
	for(i = 0;i<strlen(tmp);i++)
		name[i+9] = tmp[i] + 4;
	name[i+9] = 0;
	m_Pass.GetWindowTextA(pass,100);
	m_Ver.GetWindowTextA(tmp,4);
	_ver = ver = atoi(tmp);
	//MessageBox(name,pass,0);
	Dail();
	// TODO: Add your control notification handler code here
	//CDialogEx::OnOK();
}


bool Cras_acsiiDlg::Dail(void)
{
	int ret;
	DWORD dwBytes;
	char *pos = 0;
	char tmp[80];
	__int16 vv;
	char *Rasphone = NULL;
	if(hRasConn)
	{
		return false;
	}
	Log->SetWindowTextA((LPCTSTR)"");
	if (m_ck.GetCheck())
	{
		updatelog("Not using the default PPPOE !");
		RasGetEntryPropertiesA(NULL, 0, NULL, &dwBytes, NULL, NULL);
		//dwBytes = sizeof(RASENTRY);
		pos = (char *)malloc(dwBytes);
		memset(pos,0,dwBytes);
		*(DWORD *)pos = dwBytes;
		*(DWORD *)(pos + 0x704 + 4) = 3;
		*(DWORD *)(pos+4) = 0x08040010;
		vv = GetVersion();
		if ( (unsigned __int8)vv >= 5u && HIBYTE(vv) )
			*(DWORD *)(pos + 0x704) = 5;
		else
			*(DWORD *)(pos + 0x704) = 4;
		strcpy(pos + 0x3cc,"PPPoE");
		*(DWORD *)(pos + 0xbc) = 1;
		*(DWORD *)(pos + 0xb8) = ((unsigned __int8)vv > 5u) ? 12 : 4;
		//*(DWORD *)(pos + 0xb8) = 4;
		updatelog("start setentry \n");
		ret = RasSetEntryProperties("test","Rasphone.pbk",(tagRASENTRYA*)pos,dwBytes,0,0);
		if(ret)
		{
			sprintf(tmp,"RasSetEntryProperties error!!   %d\n",ret);
			updatelog(tmp);
			return false;
		}
		Rasphone = "Rasphone.pbk";
	}
	memset(&RasDialParams,0,sizeof(RasDialParams));
	RasDialParams.dwSize=sizeof(RasDialParams);
	RasDialParams.dwSize=1060;
	strcpy(RasDialParams.szUserName,name);
	strcpy(RasDialParams.szPassword,pass);
	strcpy(RasDialParams.szEntryName,"test");
	updatelog("start RasDial \n");
	if (ret = RasDial(NULL, Rasphone, &RasDialParams, 
		0, RasDialFunc, &hRasConn))
	{
		sprintf(tmp,"RasDial error!!   %d\n",ret);
		updatelog(tmp);
		return false;
	}
	return true;
}


void __stdcall RasDialFunc(UINT unMsg, RASCONNSTATE rascs, DWORD dwError)
{
	if (dwError)  // Error occurred
	{
		char tmp[100];
		RasGetErrorString(dwError,tmp,100);
		updatelog(tmp);
		kill_();
		return;
	}
	switch (rascs)
	{
		// Running States
		case RASCS_OpenPort:
			updatelog ("Opening port...\n");
			break;
		case RASCS_PortOpened:
			updatelog ("Port opened.\n");
        	break;
		case RASCS_ConnectDevice: 
			updatelog ("Connecting device...\n");
			break;
		case RASCS_DeviceConnected: 
			updatelog ("Device connected.\n");
			break;
		case RASCS_AllDevicesConnected:
			updatelog ("All devices connected.\n");
			break;
		case RASCS_Authenticate: 
			updatelog ("Authenticating...\n");
			break;
		case RASCS_AuthNotify:
			updatelog ("Authentication notify.\n");
			break;
		case RASCS_AuthRetry: 
			updatelog ("Retrying authentication...\n");
			break;
		case RASCS_AuthCallback:
			updatelog ("Authentication callback...\n");
			break;
		case RASCS_AuthChangePassword: 
			updatelog ("Change password...\n");
			break;
		case RASCS_AuthProject: 
			updatelog ("Projection phase started...\n");
			break;
		case RASCS_AuthLinkSpeed: 
			updatelog ("Negotiating speed...\n");
			break;
		case RASCS_AuthAck: 
			updatelog ("Authentication acknowledge...\n");
			break;
		case RASCS_ReAuthenticate: 
			updatelog ("Retrying Authentication...\n");
			break;
		case RASCS_Authenticated: 
			updatelog ("Authentication complete.\n");
			break;
		case RASCS_PrepareForCallback: 
			updatelog ("Preparing for callback...\n");
			break;
		case RASCS_WaitForModemReset: 
			updatelog ("Waiting for modem reset...\n");
			break;
		case RASCS_WaitForCallback:
			updatelog ("Waiting for callback...\n");
			break;
		case RASCS_Projected:  
			updatelog ("Projection completed.\n");
			break;
	#if (WINVER >= 0x400) 
		case RASCS_StartAuthentication:
			updatelog ("Starting authentication...\n");
            break;
		case RASCS_CallbackComplete: 
			updatelog ("Callback complete.\n");
			break;
		case RASCS_LogonNetwork:
			updatelog ("Logon to the network.\n");
			break;
	#endif 
		case RASCS_SubEntryConnected:
			updatelog ("Subentry connected.\n");
			break;
		case RASCS_SubEntryDisconnected:
			updatelog ("Subentry disconnected.\n");
			break;

		// The RAS Paused States will not occur because
		// we did not use the RASDIALEXTENSIONS structure
		// to set the RDEOPT_PausedState option flag.

		// The Paused States are:

		// RASCS_RetryAuthentication:
		// RASCS_CallbackSetByCaller:
		// RASCS_PasswordExpired:

		// Terminal States
		case RASCS_Connected: 
			//Log->SetWindowTextA("OK!!!\n");
			updatelog ("Connection completed.\n");
			showIPs();
			if (mac[0])
			{
				RASCONNSTATUS lprasconnstatus;
				memset(&lprasconnstatus,0,sizeof(lprasconnstatus));
				lprasconnstatus.dwSize = sizeof(lprasconnstatus);
				lprasconnstatus.dwSize = 288;
				if(RasGetConnectStatus(hRasConn,&lprasconnstatus) == ERROR_SUCCESS)
				{
					if (lprasconnstatus.rasconnstate == RASCS_Connected)
					{
						updatelog("RAS check OK!");
					}
					else
					{
						updatelog("error in ras");
						kill_();
						break;
					}
				}
				else updatelog("RasGetConnectStatus error");
				runing = 1;
				char cmd[100];
				sprintf(cmd,"ROUTE ADD 0.0.0.0 MASK 0.0.0.0 %s METRIC 1",IP_);
				WinExec( cmd,SW_HIDE);
				Sleep(10);
				udp_con[0] = udp_con[1] = 0;
				ras_con[0] = ras_con[1] = 0;
				AfxBeginThread(SendUDP,0,0,0,0,0);
				AfxBeginThread(checkras,0,0,0,0,0);
			}
			break;
		case RASCS_Disconnected: 
			//Log->SetWindowTextA("Done!!!\n");
			updatelog ("Disconnecting...\n");
			break;
		default:
			char tmp[30];
			sprintf(tmp,"Unknown Status = %d\n", rascs);
			updatelog (tmp);
			break;
	}
}


void Cras_acsiiDlg::OnBnClickedCancel()
{
	// TODO: Add your control notification handler code here
	if(hRasConn)
	{
		RasHangUp(hRasConn);
		updatelog("RasHangUp!");
		hRasConn = 0;
		runing = 0;
		mac[0] = 0;
		closesocket(_udp);
		//exit(0);
	}
	
	//CDialogEx::OnCancel();
}


void Cras_acsiiDlg::OnBnClickedButton1()
{

exit(0);
	// TODO: Add your control notification handler code here
}
